/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quizer.pro;

import java.io.*;
import java.util.*;

/**
 *
 * @author timbi
 */
public class Utils {

    public static Questions[] loadQuestions(String fileName, int quizNum, String courseName) {
        //declare a scanner object
        Scanner sc = null;
        //declare a new list that can store each of the student's information
        Questions[] list = new Questions[0];
        //determines the number of students in the registration file and creates a tally
        try {
            int counter = 0;
            sc = new Scanner(new File(fileName + "-" + quizNum + "-" + courseName + "[problems].txt"));
            while (sc.hasNextLine()) {
                sc.nextLine();
                counter++;
            }

            //declares the list with the counter length, so therefore the list will hold number of students in registration
            list = new Questions[counter];
            String[] length = new String[counter];

            //read from the specified file name so that it break each field and store the data into a object, therefore saved into array at index [i]
            sc = new Scanner(new File(fileName + "-" + quizNum + "-" + courseName + "[problems].txt"));
            for (int i = 0; i < list.length; i++) {
                length[i] = sc.nextLine();
                String[] fields = length[i].split(",");
                String type = fields[0];
                if (type.equals("mc")) {
                    String question = fields[1];
                    String mc1 = fields[2];
                    String mc2 = fields[3];
                    String mc3 = fields[4];
                    String mc4 = fields[5];
                    MultipleChoice mc = new MultipleChoice(type, question, mc1, mc2, mc3, mc4);
                    list[i] = mc;
                } else if (type.equals("t/f")) {
                    String question = fields[1];
                    String True = fields[2];
                    String False = fields[3];
                    TrueFalse tf = new TrueFalse(type, question);
                } else if (type.equals("numeric")) {
                    String question = fields[1];
                    Numeric n = new Numeric(type, question);
                    list[i] = n;
                }
            }
            return list;
            //catches any errors, in this case the fiule not found exceptioon is to be caughnt and said not found!
        } catch (FileNotFoundException e) {
            System.out.println("File not found!");
        }
        //return the list of students who have registered in object data type StudentInformationSystem array
        return list;
    }

    public static void quizWriteFileQ(String fileName, int quizNum, String courseName, ArrayList q) {
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(new FileWriter(fileName + "-" + quizNum + "-" + courseName + "[problems].txt", true));
            for (int i = 0; i < q.size(); i++) {
                pw.println(q.get(i));
            }
            pw.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found!");
        } catch (IOException e) {
            System.out.println("File not found!");
        }
    }

    public static void quizWriteFileA(String fileName, int quizNum, String courseName, ArrayList q) {
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(new FileWriter(fileName + "-" + quizNum + "-" + courseName + "[solutions].txt", true));
            for (int i = 0; i < q.size(); i++) {
                pw.println(q.get(i));
            }
            pw.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found!");
        } catch (IOException e) {
            System.out.println("File not found!");
        }
    }

    public static void recordResults(String studentName, String courseCode, String fileName, int quizNum, String[] array) {
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(new FileWriter(studentName + "-" + fileName + "-" + quizNum + "-" + courseCode + "[recorded_answers].txt", true));
            for (int i = 0; i < array.length; i++) {
                pw.println(array[i]);
            }
            pw.close();
        } catch (IOException e) {
            System.out.println("File not ffound!");
        }
    }

    public static void compareResults(String studentName, String courseCode, String fileName, int quizNum, String[] array) {
        Scanner sc = null;
        PrintWriter pw = null;
        String[] answers;
        String[] ra;
        String[] results;
        int counter = 0;
        try {
            ra = array;
            sc = new Scanner(new File(fileName + "-" + quizNum + "-" + courseCode + "[solutions].txt"));
            while (sc.hasNextLine()) {
                sc.nextLine();
                counter++;
            }
            answers = new String[counter];
            String[] temp = new String[counter];
            sc = new Scanner(new File(fileName + "-" + quizNum + "-" + courseCode + "[solutions].txt"));
            for (int j = 0; j < counter; j++) {
                temp[j] = sc.nextLine();
                String[] fields = temp[j].split(",");
                answers[j] = fields[6];
            }
            sc.close();
            System.out.println(temp[0] + "xd" + answers[0]);
            pw = new PrintWriter(new FileWriter(studentName + "-" + fileName + "-" + quizNum + "-" + courseCode + "[results].txt", true));
            System.out.println(ra[0] + "-" + answers[0]);
            for (int k = 0; k < counter; k++) {
                System.out.println("omegalulxdxd");
                if (ra[k].equals(answers[k])) {
                    String[] fields2 = temp[k].split(",");
                    System.out.println("LOL" + fields2[1]);
                    pw.println(fields2[1] + ",Correct");
                } else if (!ra[k].equals(answers[k])) {
                    String[] fields2 = temp[k].split(",");
                    pw.println(fields2[1] + ",Incorrect");
                }
            }
            pw.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found123!");
        } catch (IOException e) {
            System.out.println("File xd found!");
        }
    }
}
