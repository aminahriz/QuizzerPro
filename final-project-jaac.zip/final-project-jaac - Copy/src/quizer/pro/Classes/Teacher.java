/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quizer.pro.Classes;

/**
 *
 * @author amina
 */
public class Teacher {
    String firstName, lastName, email;
    String delim = ",";
    String toCSV = firstName + delim + lastName + delim + email;
    
    public String toString(){
        return toCSV;
    }
    
    public Teacher(String firstName, String lastName, String email){
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }
    
    public void addPass(String password){
        toCSV = firstName + delim + lastName + delim + email + delim + password;
    }
}
