package quizer.pro.Classes;
/**
 *
 * @author amina
 */
public class Student {
    String firstName, lastName, email, type;
    int studentNum;
    String delim = ",";
    String toCSV = studentNum + delim + firstName + delim + lastName + delim + email;
    
    public String toString(){
        return toCSV;
    }
    
    public Student(String firstName, String lastName, String email, int studentNum){
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.studentNum = studentNum;
    }
    
    public void addPass(String password){
        toCSV = studentNum + delim + firstName + delim + lastName + delim + email + delim + password;
    }
}