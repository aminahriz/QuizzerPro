/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quizer.pro.Classes;

/**
 *
 * @author amina
 */
public class Class {
    String name;
    String teacher;
    Student[] students;
    String code;
    
    //method to create a class code
    
}
